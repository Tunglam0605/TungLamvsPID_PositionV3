/*
 * MotorPID_Position.h - Multi-motor version (dynamic mapping)
 * Tác giả: Nguyễn Khắc Tùng Lâm
 * Facebook: Lâm Tùng | TikTok: @Tunglam0605 | SĐT: 0325270213
 *
 * Thư viện điều khiển vị trí động cơ DC sử dụng encoder & PID cho nhiều động cơ cùng lúc.
 * Tương thích Arduino Due, Mega, Uno... (ưu tiên Due/Mega vì nhiều interrupt hardware).
 *
 * Sử dụng:
 *   - Tạo object MotorPID_Position cho mỗi động cơ với các chân ENCA, ENCB, PWM thuận/nghịch, hệ số PID, pulses_per_rev.
 *   - Gọi .Init() trong setup() để đăng ký ngắt encoder, mapping động cơ tự động.
 *   - Trong loop, chỉ cần gọi .Position(góc) để giữ vị trí; muốn reset encoder gọi .Home();
 *   - Có thể đổi số xung/vòng, hệ số PID, giới hạn tích phân bất kỳ lúc nào.
 * 
 * Liên hệ - Kết nối:
 *   - Facebook: Lâm Tùng
 *   - TikTok: @Tunglam0605
 *   - SĐT: 0325270213
 */

#ifndef MOTORPID_POSITION_V3_H
#define MOTORPID_POSITION_V3_H

#include <Arduino.h>

#define MAX_PID_MOTORS 8  // Số lượng động cơ PID tối đa hỗ trợ

// ===============================
// ======= CLASS ĐIỀU KHIỂN ĐỘNG CƠ DC PID VỊ TRÍ ĐA KÊNH =======
// ===============================
class MotorPID_Position {
public:
    // ======== Khởi tạo động cơ (truyền chân encoder, PWM, thông số PID, số xung/vòng, dt, iSat) ========
    MotorPID_Position(uint8_t enca, uint8_t encb, uint8_t pwmF, uint8_t pwmB,
                      float kp, float ki, float kd,
                      int pulses_per_rev, float dt = 0.01, float iSat = 500.0f);

    // ======= Hàm setup ban đầu, đăng ký ngắt encoder =======
    void Init();

    // ======= Hàm PID chạy liên tục về vị trí target_angle =======
    void Position();                 // Gọi trong loop để motor quay về target_angle
    void Position(float angle);      // Đặt góc đích mới, motor sẽ PID về góc này

    // ======= Quay n vòng so với vị trí hiện tại (vị trí + n*360) =======
    void moveNRound(float n);

    // ======= Bật/tắt PID giữ vị trí =======
    void setEnable(bool en);

    // ======= Ngắt động cơ, tắt PWM =======
    void Stop();

    // ======= Đặt lại home: dừng motor, đặt vị trí hiện tại là 0 =======
    void Home();

    // ======= Reset bộ PID (xóa sai số trước đó) =======
    void ResetPID();

    // ======= Đổi số xung/vòng encoder =======
    void setPulsePerRev(int ppr);

    // ======= Set lại thông số PID =======
    void setPID(float kp, float ki, float kd);

    // ======= Tùy chỉnh offset bộ PID nhanh (chạy về nhanh hơn khi sai số lớn) =======
    void setFastPIDOffset(float kp_off, float kd_off);

    // ======= Đặt ngưỡng bão hòa tích phân (chống tràn i) =======
    void setISat(float iSat);

    // ======= Đọc góc hiện tại (độ) =======
    float getCurrentAngle();

    // ======= Đọc số xung hiện tại =======
    long  getCurrentPulse();

    // ======= Đọc góc target hiện tại =======
    float getTargetAngle();

    // ======= Kiểm tra đã bật PID chưa =======
    bool  isEnabled();

    // ================================
    // ====== ĐIỀU KHIỂN SERIAL (nhiều động cơ đồng thời) ======
    // ================================
    static void initSerialControl(HardwareSerial* ser, long baud); // Khởi tạo cổng Serial
    static void handleSerialControl(MotorPID_Position** motors, int numMotors); // Đọc lệnh Serial, điều khiển từng motor

    // ======= HOMING (đưa về gốc) CHO 1 ĐỘNG CƠ =======
    static void autoHome(
        MotorPID_Position* motor,   // Đối tượng motor cần home
        int sensorPin,              // Chân cảm biến home
        int pwmF, int pwmB,         // PWM thuận/nghịch
        int pwmSpeed,               // Tốc độ home
        bool direction,             // true: thuận, false: nghịch
        float angleOffset,          // Góc bù sau khi home (do lệch lắp đặt)
        int homeThreshold = 127     // Ngưỡng cảm biến (ADC)
    );

    // ======= HOMING CHO NHIỀU ĐỘNG CƠ (tối ưu cho robot đa trục) =======
    static void autoHomeAll(
        MotorPID_Position* motors[],    // Mảng con trỏ động cơ
        int sensorPins[],               // Mảng cảm biến home
        int pwmFs[], int pwmBs[],       // PWM thuận/nghịch từng động cơ
        int pwmSpeeds[],                // Tốc độ từng động cơ
        bool directions[],              // Chiều home từng động cơ
        float angleOffsets[],           // Mảng góc bù
        int numMotors,                  // Số động cơ
        int homeThreshold = 127         // Ngưỡng cảm biến (ADC)
    );

    // ======= Danh sách con trỏ đến các motor, phục vụ ngắt toàn cục =======
    static MotorPID_Position* motorList[MAX_PID_MOTORS];
    static uint8_t motorCount;

private:
    // ============ Các biến riêng từng motor ============
    uint8_t enca, encb, pwmF, pwmB;     // Chân encoder A/B, PWM thuận/nghịch
    volatile long posi;                 // Biến đếm encoder (volatile do dùng trong ngắt)
    int pulses_per_rev;                 // Số xung trên 1 vòng
    float kp, ki, kd;                   // Thông số PID cơ bản
    float kp_offset, kd_offset;         // Offset PID (tăng tốc khi sai số lớn)
    float kp_fast, ki_fast, kd_fast;    // PID "nhanh" khi lệch lớn
    float dt, iSat;                     // Chu kỳ tính PID (giây), giới hạn tích phân
    float eprev, eintegral;             // Lưu sai số trước đó & tích phân
    float target_angle, snapshot_angle;  // Góc đích & góc snapshot khi đặt lệnh
    volatile int lastEncoded;           // Bộ nhớ trạng thái encoder (giải thuật quadrature)
    unsigned long lastCompute;          // Thời gian tính PID cuối cùng
    bool enabled, autoCorrection;       // Cờ bật PID, tự động correction

    // ============ Hàm xử lý ngắt encoder, tính toán PID, điều khiển động cơ ============
    void handleEncoderInterrupt();
    void computePID();
    void setMotor(int dir, int pwm);

    // ============ Ngắt encoder toàn cục (multi motor support) ============
    static void globalEncoderISR_A();
    static void globalEncoderISR_B();

    // ============ Giao tiếp Serial ============
    static HardwareSerial* serialPort;
    static String serialBuffer;
};

#endif
